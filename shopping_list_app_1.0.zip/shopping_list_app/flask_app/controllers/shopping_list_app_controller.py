from flask_app import app
from flask import render_template, redirect, request, session, flash
#from flask_app.models.user_model import User
from flask_app.models.user_model import User
from flask_app.models.store_model import Store
from flask_app.models.items_model import Items
#from flask_app.models.store_model import Store
#from flask_app.models.items_model import Items
from flask_bcrypt import Bcrypt     
bcrypt = Bcrypt(app)

#There will be other imports need depending what you're trying to use in this file
#You will also need a bycrypt import (we will introduce this week 5)


@app.route('/') #Get request for 127.0.0.1:5000
def home():
    return render_template('index.html')

@app.route('/YourShoppingList')
def all_stores():
    
    return render_template('stores.html', store = Store.get_stores_w_users())

# @app.route('/name of path/route goes here!', methods=['POST']) #Post request route
# def rename1():
#     return redirect('/route path goes here!')

# @app.route('/dashboard')
# def rename2():
#     return render_template('Dashboard html page here!')

@app.route('/register', methods=['POST']) 
def register():
    if not User.validate_user(request.form):
        print("We made it here! HEHE!")
        print(request.form)
        return redirect('/')
    pw_hash = bcrypt.generate_password_hash(request.form['password'])
    print(pw_hash)
    data = {
        "email": request.form['email'],
        "password": pw_hash
    }
    user_in_db = User.find_User(data)
    if user_in_db:
        flash("Email already in use!!")
        return redirect("/")
    registry_id = User.save(data)
    print("THIS MEANS SUCESS!!")
    #session['email'] = request.form['email']
    session['registry_id'] = registry_id
    print(registry_id)
    return redirect('/')

@app.route('/login', methods=['POST'])
def login():
    data = {
        'email' : request.form['email'],
        'password' : request.form['password']
    }
    user_in_db2 = User.find_User2(data)
    if not user_in_db2:
        flash("Invalid email/password!")
        return redirect("/")
    if not bcrypt.check_password_hash(user_in_db2.password, request.form['password']):
        flash("Invalid Email/Password!!!!!")
        return redirect('/')
    session['user_id'] = user_in_db2.id
    session['email'] = user_in_db2.email
    return redirect('/YourShoppingList')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/newstore')
def newrec():
    return render_template('create_store.html')

@app.route('/newlist/<int:id>')
def newre(id):
    value = Store.get_one_store(id)
    return render_template('create_list.html', value=value)

#,store = Store. get_one_store_one_user()

# app.route('/create_store', methods=['POST'])
# def create_store():
#     # if not Store.validate_store(request.form):
#     #     print("We made it here!")
#     #     print(request.form)
#     #     return redirect('/newstore')
#     data = {
#         #"id": session['user_id'],
#         "user_id": session['user.id'],
#         'store_name' : request.form['store_name'],
#         'location' : request.form['location']
#         # "user_id": session['user_id'],
#         # "id": request.form['id']
#     }
#     store_id = Store.save_store(data)####
#     print("THIS MEANS SUCESS!!")
#     session['store_name'] = request.form['store_name']
#     session['store_id'] = store_id
#     print(store_id)
#     return redirect('/YourShoppingList')

@app.route('/create_st', methods=["POST"])
def create_user():
    data = {
        "user_id": session['user_id'],
        "store_name": request.form["store_name"],
        "location": request.form["location"],
    }
    user_id = Store.save_store(data)
    session['user_id'] = user_id
    print(user_id)
    return redirect('/newlist/'+str(user_id))

@app.route('/create_li', methods=["POST"])
def create_lis():
    data = {
        #"store_user_id": request.form['store.user.id'],
        #"store_user_id": session['user_id'],
        "store_id": request.form['store_id'],
        "item_name": request.form["item_name"],
        "price": request.form["price"]
    }
    store_id = Items.save_item(request.form)
    session['user_id'] = store_id

    print(store_id)
    return redirect('/YourShoppingList')