from flask_app.config.mysqlconnection import connectToMySQL
from flask import flash
#from flask_app import store_model
#from flask_app import items_model
import re
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
#might need other imports like flash other classes and regex



class User:
    db = 'shopping_list_app'
    def __init__(self, data):
        self.id = data['id']
        self.created_at = data['updated_at']
        self.updated_at = data['created_at']
        self.first_name = data['first_name']
        self.last_name = data['last_name']
        self.email = data['email']
        self.password = data['password']
        self.store= []
        self.items= []
        #follow database table fields plus any other attribute you want to create
        pass


    @classmethod
    def rename(cls):
        query = "SELECT * FROM user;"
        results = connectToMySQL("shopping_list_app").query_db(query)
        #Nice little head start
        #Rest of code here
        print(results)
        return "Something here"
    
    @classmethod
    def allUsers(cls):
        query = "SELECT * FROM user;"
        results = connectToMySQL("shopping_list_app").query_db(query)
        print(results)
        return results
    
    @classmethod
    def save(cls,data):
        query = """INSERT INTO user (id, created_at, updated_at, first_name, last_name, email, password )
                VALUES (DEFAULT, NOW(), NOW(), %(first_name)s, %(last_name)s, %(email)s, %(password)s);"""
        return connectToMySQL("shopping_list_app").query_db(query, data)
    
    @staticmethod
    def validate_user(user):
        is_valid = True
        print("#############################################")
        if not EMAIL_REGEX.match(user['email']): 
            flash("Invalid email/password address!")
            is_valid = False
            #return is_valid
        if len(user['password']) < 8:
            flash("Password must be at least 8 characters.")
            is_valid = False
        if user['password'] != user['confirm']:
            flash("Passwords must match")
            is_valid = False
        return is_valid
    
    #@classmethod
    #def find_User(cls, email_dict):
        query = "SELECT * from user WHERE email = %(email)s"
        db_response = connectToMySQL(db).query_db(query, email_dict)
        print(db_response)
        if len(db_response) < 1:
            return False
        return db_response
    
    #@classmethod
    #def find_User2(cls, email_dict):
        query = "SELECT * from user WHERE email = %(email)s"
        db_response = connectToMySQL(db).query_db(query, email_dict)
        print(db_response)
        if len(db_response) < 1:
            return False
        return cls(db_response[0])
    
    #Steven
    @classmethod
    def get_user_by_id(cls, data):
        """Get the user by id"""
        query = "SELECT * FROM user WHERE id = %(id)s;"
        return cls(connectToMySQL(cls.db).query_db(query, data)[0])

    @classmethod
    def get_user_by_email(cls, data):
        """Get user by email"""
        query = "SELECT * FROM user WHERE email = %(email)s;"
        result = connectToMySQL(cls.db).query_db(query, data)
        return cls(result[0])

    @classmethod
    def get_all_users(cls,data):
        """Get all users"""
        query = "SELECT * FROM user;"
        results = connectToMySQL(cls.db).query_db(query,data)
        all_users = []
        for u in results:
            all_users.append(cls(u))
        return all_users

    @classmethod
    def is_valid_user(cls,user):
        is_valid = True
        query = "SELECT * FROM user WHERE email = %(email)s;"
        results = connectToMySQL(User.db).query_db(query,user)
        if len(results) >= 1:
            flash("Email associated with another user.", "register")
            is_valid = False
        if not EMAIL_REGEX.match(user['email']):
            flash("Invalid Email!", "register")
            is_valid = False
        if len(user["first_name"]) <= 3:
            is_valid = False
            flash("First name is required.", "register")
        if len(user["last_name"]) <= 3:
            flash("Last name is required.", "register")
            is_valid = False
        if len(user["password"]) <= 8:
            flash("Password must be at least 8 characters.", "register")
            is_valid = False
        if user['password'] != user['confirm']:
            flash("Passwords must match", "register")
        return is_valid

    @staticmethod
    def validate_account(user):
            is_valid = True
            if len(user['first_name']) < 3:
                flash("The first name must be at least 3 characters.", "danger")
                is_valid = False
            if len(user['last_name']) < 3:
                flash("The last name must be at least 3 characters.", "danger")
                is_valid = False
            if len(user['email']) < 3:
                flash("The email must be at least 3 characters.", "danger")
                is_valid = False
            if not EMAIL_REGEX.match(user['email']):
                flash("Email is not valid!", "danger")
                is_valid = False
                return is_valid
            return is_valid