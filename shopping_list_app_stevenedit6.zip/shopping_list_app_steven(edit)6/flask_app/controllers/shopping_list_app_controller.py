from flask_app import app
from flask import render_template, redirect, request, session, flash
#from flask_app.models.user_model import User
from flask_app.models.user_model import User
from flask_app.models.store_model import Store
from flask_app.models.items_model import Items
#from flask_app.models.store_model import Store
#from flask_app.models.items_model import Items
from flask_bcrypt import Bcrypt     
bcrypt = Bcrypt(app)

#There will be other imports need depending what you're trying to use in this file
#You will also need a bycrypt import (we will introduce this week 5)


@app.route('/') #Get request for 127.0.0.1:5000
def home():
    return render_template('index.html')

@app.route('/YourShoppingList')
def all_stores():
    if 'user_id' not in session:
        return redirect('/logout')
    data ={
        'id': session['user_id']
    }
    return render_template('stores.html', store = Store.get_stores_w_users(), user = User.get_user_by_id(data))

#@app.route('/YourShoppingList')
#def dashboard():
    """Welcome page"""
    if 'id' not in session:
        flash("Please register or login to continue", "danger")
        return redirect('/')

    data = {
        'id': session['id']
    }

    one_user = User.find_User(data)
    if one_user:
        session['email'] = one_user.email
        session['first_name'] = one_user.first_name
        session['last_name'] = one_user.last_name

    all_stores = Store.get_stores_w_users()
    print(all_stores)
    return render_template('YourShoppingList', one_user=one_user, all_stores = all_stores)





# @app.route('/name of path/route goes here!', methods=['POST']) #Post request route
# def rename1():
#     return redirect('/route path goes here!')

@app.route('/dashboard')
def rename2():
    return render_template('Dashboard html page here!')
#####Nates
# @app.route('/register', methods=['POST']) 
# def register():
#     if not User.validate_user(request.form):
#         print("We made it here! HEHE!")
#         print(request.form)
#         return redirect('/')
#     pw_hash = bcrypt.generate_password_hash(request.form['password'])
#     print(pw_hash)
#     data = {
#         "email": request.form['email'],
#         "password": pw_hash
#     }
#     user_in_db = User.find_User(data)
#     if user_in_db:
#         flash("Email already in use!!")
#         return redirect("/")
#     registry_id = User.save(data)
#     print("THIS MEANS SUCESS!!")
#     #session['email'] = request.form['email']
#     session['registry_id'] = registry_id
#     print(registry_id)
#     return redirect('/')
########OLD PROJECT########
@app.route('/register', methods=['POST']) 
def register():
    if not User.validate_user(request.form):
        print("We made it here! HEHE!")
        print(request.form)
        return redirect('/')
    pw_hash = bcrypt.generate_password_hash(request.form['password'])
    print(pw_hash)
    data = {
        "first_name": request.form['first_name'],
        "last_name": request.form['last_name'],
        "email": request.form['email'],
        "password": pw_hash
    }
    user_in_db = User.find_User(data)
    if user_in_db:
        flash("Email already in use!!")
        return redirect("/")
    registry_id = User.save(data)
    print("THIS MEANS SUCESS!!")
    #if not redirecting no reason to create session here
    session['first_name'] = request.form['first_name']
    session['registry_id'] = registry_id
    print(registry_id)
    return redirect('/')

######


@app.route('/login', methods=['POST'])
def login():
    data = {
        'email' : request.form['email'],
        'password' : request.form['password']
    }
    user_in_db2 = User.find_User2(data)
    if not user_in_db2:
        flash("Invalid email/password!")
        return redirect("/")
    if not bcrypt.check_password_hash(user_in_db2.password, request.form['password']):
        flash("Invalid Email/Password!!!!!")
        return redirect('/')
    session['user_id'] = user_in_db2.id
    print("this is session",user_in_db2.id)
    session['email'] = user_in_db2.email
    return redirect('/YourShoppingList')

#Steven
# @app.route('/register', methods=['POST'])
# def register():
#     user_info = request.form
#     if not User.is_valid_user(user_info):
#         return redirect ('/')
#     data = {
#         "first_name": request.form['first_name'],
#         "last_name": request.form['last_name'],
#         "email": request.form['email'],
#         "password": bcrypt.generate_password_hash(request.form['password'])
#     }
#     id = User.save(data)
#     session['user_id'] = id
#     return redirect('/')

# # steven
# @app.route('/login', methods=['POST','GET'])
# def login():
#     """Login in the user"""
#     data = { 
#         'email': request.form['email'],
#     }
#     user_in_db = User.get_user_by_email(data)
#     print("HHEEEEEEEEEEEEYYYYYYYY!!!!!!!!!",user_in_db)
#     if not user_in_db:
#         flash("Invalid Email or Need to register", "danger")
#         return redirect('/')
#     if not bcrypt.check_password_hash(user_in_db.password, request.form['password']):
#         flash("The password must match and be at least 8 characters, and contain at least one each of the following: one upper, one lower, one digit and one special character.", "danger")
#         return redirect('/')
#     session['user_id'] = user_in_db.id
#     return redirect('/YourShoppingList')

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/newstore')
def newrec():
    return render_template('create_store.html')

@app.route('/newlist/<int:id>')
def newre(id):
    value = Store.get_one_store(id)
    return render_template('create_list.html', value=value)

#,store = Store. get_one_store_one_user()

# app.route('/create_store', methods=['POST'])
# def create_store():
#     # if not Store.validate_store(request.form):
#     #     print("We made it here!")
#     #     print(request.form)
#     #     return redirect('/newstore')
#     data = {
#         #"id": session['user_id'],
#         "user_id": session['user.id'],
#         'store_name' : request.form['store_name'],
#         'location' : request.form['location']
#         # "user_id": session['user_id'],
#         # "id": request.form['id']
#     }
#     store_id = Store.save_store(data)####
#     print("THIS MEANS SUCESS!!")
#     session['store_name'] = request.form['store_name']
#     session['store_id'] = store_id
#     print(store_id)
#     return redirect('/YourShoppingList')

@app.route('/create_st', methods=["POST"])
def create_user():
    data = {
        "user_id": session['user_id'],
        "store_name": request.form["store_name"],
        "location": request.form["location"],
    }
    store_id = Store.save_store(data)
    print(store_id)
    return redirect(f'/newlist/{str(store_id)}')

@app.route('/create_li', methods=["POST"])
def create_lis():
    data = {
        #"store_user_id": request.form['store.user.id'],
        "store_user_id": session['user_id'],
        "store_id": request.form['store_id'],
        "item_name": request.form["item_name"],
        "price": request.form["price"]
    }
    store_id = Items.save_item(request.form)
    #session['user_id'] = store_id

    print(store_id)
    return redirect('/YourShoppingList')

#STEVEN
#@app.route('/items/show/<int:store_id>')
#def show_items(store_id):
    data = {"user_id":int(store_id)}
    return render_template("view_list.html", item=Items.get_items_one_store(data))


@app.route('/shopping/<int:id>')
def one_store_plus_items(id):

    return render_template('view_list.html', value = Items.get_items_one_store(id), store=Store)

@app.route('/delete/<int:id>/')
def delete(id):
    data = {
        'id' : id
    }
    Store.delete(data)
    return redirect('/YourShoppingList')

@app.route('/delete_item/<int:id>/')
def delete_items(id):
    data = {
        'id' : id
        
    }
    Items.delete_item(data)
    return redirect('/YourShoppingList')

@app.route('/show_one/<int:id>')
def one_store_plus_items1(id):

    return render_template('show_store.html', value = Items.get_items_one_store(id), store=Store)

@app.route('/update_li', methods=["POST"])
def create_lisss():
    data = {
        #"store_user_id": request.form['store.user.id'],
        #"store_user_id": session['user_id'],
        "store_id": request.form['store_id'],
        "item_name": request.form["item_name"],
        "price": request.form["price"]
    }
    store_id = Items.update_item(request.form)
    #session['user_id'] = store_id

    print(store_id)
    return redirect('/YourShoppingList')