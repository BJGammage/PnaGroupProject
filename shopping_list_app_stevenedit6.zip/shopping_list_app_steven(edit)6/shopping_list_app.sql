SELECT * FROM items

